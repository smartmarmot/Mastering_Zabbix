#!/bin/sh
#
# check_ora.sh an Oracle query dispatcher
# Version: 0.4 
# Date: 19/03/2009
# Authors: Stefano Lee <stefano.lee@altran.it>, Andrea Dalle Vacche <andrea.dallevacche@gmail.com>
# Licence: MIT
#
##
# 0.4 Added response time of connection in second
# 0.3 Added TNSPing reponse time in msec (corrected some bug)
# 0.2 Added TNSPing reponse time in msec
### Dependencies ###
# a working sqlplus and tnsping , with correctly defined Oracle environment
#
### Files ###
# check_ora.sh: this script
# $SCRIPTDIR/credentials: one line for every instance, 
#                         with sqlplus syntax (user/pwd@inst)
# $SCRIPTDIR/<query>.sql: one file per query
#
### Usage ### 
# check_ora.sh -i Instance -q Query
# check_ora.sh -i Instance -t
# check_ora.sh -d Query
# check_ora.sh -h
# 
### Zabbix Config ###
# check type: external check
# key: check_ora.sh[-i instance -q query]
#

### Config ###
# You may need to edit the following two variables
SCRIPTDIR="/etc/zabbix/externalscripts/check_ora"
CONNFILE="$SCRIPTDIR/credentials"

# Don't need to edit from here 'till the end
### Initialization ###
INST=
QUERY=
CONNECTION=
DESCFLAG=
QUERYFLAG=

### Functions ###
printhelp() {
	echo "check_ora.sh - an Oracle query dispatcher"
	echo "Usage: check_ora.sh [-ih] [instance] [-qdst]"
	echo "       -i instance    to retrieve credentials from credentials file"
	echo "       -h             this help"
	echo "       -q query       execute a query and return just only the output"
	echo "       -d query       return a description of 'query'"
	echo "       -t             for tnsping responsetime"
	echo "       -s             for sqlplus login connection and return time in second"
}

exectnsping () {
	tnsping $1 | tail -n1 
}

descquery () {
	QUERYFILE="$SCRIPTDIR/$1.sql"
	grep '^--' $QUERYFILE
}
	
execquery () {
start_time=$(date +%s)
#        echo "Time duration: $((finish_time - start_time)) secs."
echo "BEGIN check_ora.sh  $1 $2 `date`"  >> /tmp/checkora.log
	cd $SCRIPTDIR;
	sqlplus -S $1 <<EOF | sed  -e 's/^\ *//g'
set echo off;
set tab off;
set pagesize 0;
set feedback off;
set trimout on;
set heading off;
ALTER SESSION SET NLS_NUMERIC_CHARACTERS = '.,';
@$2
EOF
finish_time=$(date +%s)
echo "END check_ora.sh  $1 $2 `date`"  >> /tmp/checkora.log
echo "check_ora.sh  $1 $2 Time duration: $((finish_time - start_time)) secs."  >> /tmp/checkora.log
}	

justconnect () {
        sqlplus -S $1 <<EOF 
set echo off;
set tab off;
set pagesize 0;
set feedback off;
set trimout on;
set heading off;
ALTER SESSION SET NLS_NUMERIC_CHARACTERS = '.,';
select 'OK' from dual;
exit;
EOF
}


### Main Execution ###
# Zabbix will call the script like this:
# check_ora.sh hostname [parameters]
# but we are only interested in parameters,
# so we ignore the first argument
# (easier from the command line, too)
if [ "${1:0:1}" != "-" ]; then shift; fi	


#### Options loop ####
while getopts "hi:q:d:ts" opt
do	
	case $opt in
	h)	printhelp
		exit 0;;
	i)	QFLAG=1
		INST="$OPTARG";;
	q)	QUERY="$OPTARG";;
	d)	DFLAG=1
		QUERY="$OPTARG";;
	t)	TFLAG=1;;
	s)	SFLAG=1;;
	?)  printhelp
		exit;;
	esac
done

#### Main branches ####
if [ "$DFLAG" = 1 ]; then
	descquery $QUERY;
	exit 0;
fi

if [ "$SFLAG" = 1 ]; then
        source /home/zabbix/.bash_profile || exit 3;
        START=$(date +%s.%N);
 	CONNECTION=$( grep $INST\; $CONNFILE | cut -d\; -f2) || exit 3;
	RESULT=$( justconnect $CONNECTION  );
	if [ "$RESULT" == "OK" ]; then
		END=$(date +%s.%N);
		DIFF=$(echo "$END - $START" | bc);
		echo $DIFF; 
                exit 0;
	else
        	echo "-1";
		exit 0;
        fi
fi

if [ "$TFLAG" = 1 ]; then
        source /home/zabbix/.bash_profile || exit 3;
	CONNECTION=$( grep $INST\; $CONNFILE | cut -d@ -f2) || exit 3;
	RESULT=$( exectnsping $CONNECTION  );
	OK=$( echo $RESULT  |cut -d " " -f1);
	RESULT=$( echo $RESULT |cut -d "(" -f2|cut -d " " -f1);
	if [ "$OK" == 'OK' ]; then
        	echo -e $RESULT;
                exit 0;
        fi
        echo "-1";
        exit 0;
fi

if [ "$QFLAG" = 1 ]; then
	source /home/zabbix/.bash_profile || exit 3;
	CONNECTION=$( grep $INST\; $CONNFILE | cut -d\; -f2) || exit 3;
	RESULT=$( execquery $CONNECTION $QUERY.sql );
	if [ -z "$RESULT" ]; then
		echo "none";
		exit 0;
	fi
	echo -e $RESULT;
	exit 0;
fi

printhelp;
exit 0;
