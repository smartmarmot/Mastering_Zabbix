-- Descrizione di cosa
-- fa la query,
-- possibilmente con tipo di output

select count(*) from v$session;
quit;
