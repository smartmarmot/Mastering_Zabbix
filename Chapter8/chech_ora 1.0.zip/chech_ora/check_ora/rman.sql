exec rmancheck;
select * from rman_24 where  starttime >= (SYSDATE - 24/24)  and STATUS like '%ERROR%';
quit;
