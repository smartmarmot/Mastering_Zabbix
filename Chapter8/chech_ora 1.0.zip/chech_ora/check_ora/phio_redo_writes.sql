select to_char(sum(decode(name,'redo writes',value,0)))
FROM V$SYSSTAT 
where  name ='redo writes';
quit;
