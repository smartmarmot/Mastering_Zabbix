SELECT to_char(SUM(DECODE(NAME,'db block changes',VALUE,0)))
FROM V$SYSSTAT 
WHERE NAME ='db block changes';
quit;
