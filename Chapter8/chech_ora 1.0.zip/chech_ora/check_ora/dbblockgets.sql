select to_char(sum(decode(name,'db block gets', value,0))) "block_gets"
FROM v$sysstat;
quit;
