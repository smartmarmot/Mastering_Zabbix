-- Descrizione di cosa
-- fa la query,
-- possibilmente con tipo di output

select SUM(Decode(Type, 'BACKGROUND', 1, 0)) system_sessions
FROM V$SESSION;
quit;
