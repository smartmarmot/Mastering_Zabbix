select * from 
(select 'Tabls Name='||d.tablespace_name "Tablespace Name", 
    '| Size MB='||round(sum(d.bytes))/1048576 "size MB", 
    '| Free MB=',FREESPCE/1048576 "free MB", 
    '| Used MB='||round((sum(d.bytes)-FREESPCE)/1048576) "used MB", 
    '| Autoext='||max(AUTOEXTENSIBLE) "autoextend",
    '| Max  MB='||sum(d.maxbytes)/1048576 "maxsize MB" ,
    '| Used (%)=' , CASE WHEN sum(d.maxbytes) = 0 THEN round((sum(d.bytes)-FREESPCE) / sum(d.bytes)*100)
        ELSE (sum(d.bytes)-FREESPCE)/sum(d.maxbytes)*100
        --/sum(d.maxbytes)*100
        END used,
        '<br />'
    from dba_data_files d,
    (  SELECT sum(f.bytes) FREESPCE, f.tablespace_name Tablespc 
        FROM dba_free_space f 
        GROUP BY f.tablespace_name
        ) 
WHERE d.tablespace_name = Tablespc (+)
group by d.tablespace_name,FREESPCE 
order by 8 desc
)
where used > 93;
exit;
