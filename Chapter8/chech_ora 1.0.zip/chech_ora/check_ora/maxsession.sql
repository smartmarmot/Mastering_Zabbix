select value "maxsess" from v$parameter where name = 'sessions';
quit;
