select gethitratio*100 "get_pct"
FROM v$librarycache
where namespace ='SQL AREA';
quit;
