SELECT to_char(ROUND(SUM(decode(pool,NULL,decode(name,'db_block_buffers',(bytes)/(1024*1024),
    'buffer_cache',(bytes)/(1024*1024),0),0)),2)) sga_bufcache
FROM V$SGASTAT;
quit;
