select to_char(sum(decode(name,'physical reads direct',value,0)))
FROM V$SYSSTAT 
where  name ='physical reads direct';
quit;
