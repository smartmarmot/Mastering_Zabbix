SELECT  to_char(sum(decode(name,'consistent gets',value,0)))
FROM V$SYSSTAT 
WHERE NAME ='consistent gets';
quit;
