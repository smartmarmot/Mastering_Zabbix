#!/bin/bash
#
# here i'm importing all environment needed
source /etc/zabbix/externalscripts/check_ora/globalcfg

#going to get the host's list
gethosts () {
	cd /etc/zabbix/externalscripts/check_ora
	cat credentials | grep -v '^#' | cut -d';' -f 1
}

#
getqueries () {
	cd /etc/zabbix/externalscripts/check_ora
	ls *.sql
}


HOSTS=$(gethosts)
QUERIES=$(getqueries)


cd /etc/zabbix/externalscripts
for host in $HOSTS; do
	for query in $QUERIES; do
		./check_ora_sendtrap.sh -r -i $host -q ${query%.sql} &		
		sleep 5
	done;
	./check_ora_sendtrap.sh -r -i $host -t &
	sleep 5
	./check_ora_sendtrap.sh -r -i $host -s &
done;
 
