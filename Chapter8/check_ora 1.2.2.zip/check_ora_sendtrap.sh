#!/bin/sh
#
# check_ora_sendtrap.sh an Oracle query dispatcher
# Version: 1.2
# Date: 04/02/2010
# Authors: Andrea Dalle Vacche <andrea.dallevacche@gmail.com>, Stefano Lee <stefano.lee@altran.it>
# Licence: GPL 2
#
##
# 1.2 added a check on archivelog produced, the value is calculated on an average of 10 minute, there a trigger included that warn if
#     more than 100MB/minute are produced really useful if you have some dataguard-configuration
# 1.1 added some improvements, correct some minor bugs, and added some comments, and created an external configuration file
# 0.4 Added response time of connection in second
# 0.3 Added TNSPing reponse time in msec (corrected some bug)
# 0.2 Added TNSPing reponse time in msec
### Dependencies ###
# a working sqlplus and tnsping , with correctly defined Oracle environment
#
### Files ###
# check_ora_sendtrap.sh: this script
# $SCRIPTDIR/credentials: one line for every instance, 
#                         with sqlplus syntax (user/pwd@inst)
# $SCRIPTDIR/<query>.sql: one file per query
#
### Usage ### 
# check_ora_sendtrap.sh -i Instance -q Query
# check_ora_sendtrap.sh -i Instance -t
# check_ora_sendtrap.sh -d Query
# check_ora_sendtrap.sh -h
# 
### Zabbix Config ###
# check type: external check
# key: check_ora.sh[-i instance -q query]
#

### Config ###
# You may need to edit the following two variables

source /etc/zabbix/externalscripts/check_ora/globalcfg

# Don't need to edit from here 'till the end
### Initialization ###
INST=
QUERY=
CONNECTION=
DESCFLAG=
QUERYFLAG=
### Functions ###
printhelp() {
	    echo "check_ora_sendtrap.sh - an Oracle query dispatcher"
        echo "Usage: check_ora_sendtrap.sh [-r] [-ih] [instance] [-qdst]"
        echo "       -r             send remotely the retrieved value without this option don't use zabbixsend"
        echo "       -i instance    to retrieve credentials from credentials file"
        echo "       -h             this help"
        echo "       -q query       execute a query and return just only the output"
        echo "       -d query       return a description of 'query'"
        echo "       -t             for tnsping responsetime"
        echo "       -s             for sqlplus login connection and return time in second"
}

exectnsping () {
	tnsping $1 | tail -n1 
}

#print description finded inside QUERYFILE
#to find description i simply grep each line that begin with -- ant print out.
descquery () {
	QUERYFILE="$SCRIPTDIR/$1.sql"
	grep '^--' $QUERYFILE
}
	
#here i'm going to execute the query
execquery () {
	cd $SCRIPTDIR;
	sqlplus -S $1 <<EOF | sed  -e 's/^\ *//g'
set echo off;
set tab off;
set pagesize 0;
set feedback off;
set trimout on;
set heading off;
ALTER SESSION SET NLS_NUMERIC_CHARACTERS = '.,';
@$2
EOF
}	

justconnect () {
        sqlplus -S $1 <<EOF 
set echo off;
set tab off;
set pagesize 0;
set feedback off;
set trimout on;
set heading off;
ALTER SESSION SET NLS_NUMERIC_CHARACTERS = '.,';
select 'OK' from dual;
exit;
EOF
}

send () {
	MYHOST="$1"
	MYKEY="$2"
	MYMSG="$3"

	if [ "$RFLAG" = 1 ]; then 
		$ZBX_SENDER -z $ZBX_SERVER -p $ZBX_PORT -s $MYHOST -k $MYKEY -o "$MYMSG"; 
		#echo "$ZBX_SENDER -z $ZBX_SERVER -p $ZBX_PORT -s $MYHOST -k $MYKEY -o "; #$MYMSG"; 
	else
		echo $MYMSG;
	fi
}

### Main Execution ###
# Zabbix will call the script like this:
# check_ora_sendtrap.sh hostname [parameters]
# but we are only interested in parameters,
# so we ignore the first argument
# (easier from the command line, too)
if [ "${1:0:1}" != "-" ]; then shift; fi	


#### Options loop ####
while getopts "hi:q:d:tsr" opt
do	
	case $opt in
	h)	printhelp
		exit 0;;
	i)	QFLAG=1
		INST="$OPTARG";;
	q)	QUERY="$OPTARG";;
	d)	DFLAG=1
		QUERY="$OPTARG";;
	t)	TFLAG=1;;
	s)	SFLAG=1;;
	r)	RFLAG=1;;
	?)  printhelp
		exit;;
	esac
done

#### Main branches ####
if [ "$DFLAG" = 1 ]; then
	descquery $QUERY;
	exit 0;
fi

if [ "$SFLAG" = 1 ]; then
        START=$(date +%s.%N);
 	CONNECTION=$( grep $INST\; $CONNFILE | cut -d\; -f2) || exit 3;
	RESULT=$( justconnect $CONNECTION  );
	if [ "$RESULT" == "OK" ]; then
		END=$(date +%s.%N);
		DIFF=$(echo "$END - $START" | bc);
		send $INST "connection" "$DIFF";
                exit 0;
	else
		send $INST "connection" "-1";
        	#echo "-1";
		exit 0;
        fi
fi

if [ "$TFLAG" = 1 ]; then
	CONNECTION=$( grep $INST\; $CONNFILE | cut -d@ -f2) || exit 3;
	RESULT=$( exectnsping $CONNECTION  );
	OK=$( echo $RESULT  |cut -d " " -f1);
	RESULT=$( echo $RESULT |cut -d "(" -f2|cut -d " " -f1);
	if [ "$OK" == 'OK' ]; then
        	#echo -e $RESULT;
		send $INST "tnsping" "$RESULT"
                exit 0;
        fi
        #echo "-1";
	send $INST "tnsping" "-1";
        exit 0;
fi

if [ "$QFLAG" = 1 ]; then
	CONNECTION=$( grep $INST\; $CONNFILE | cut -d\; -f2) || exit 3;
	RESULT=$( execquery $CONNECTION $QUERY.sql);
	if [ -z "$RESULT" ]; then
		#echo "none";
		send $INST $QUERY "none"
		exit 0;
	fi
	#echo -e $RESULT;
	send $INST $QUERY "$RESULT"
	exit 0;
fi

printhelp;
exit 0;
