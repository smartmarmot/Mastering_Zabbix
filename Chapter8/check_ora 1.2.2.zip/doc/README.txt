Author
------
Andrea Dalle Vacche: rootzone.wordpress.com
Everyone can read the full story of this plugin here: http://www.zabbix.com/forum/showthread.php?t=13666

About
-----
This plug-in was made to monitor oracle instances with zabbix, with this you are going to acquire data from 
every oracle instances that you wanto to monitor and then zabbix server is going to produce graphs and collect data.
For most of data collected are present some trigger that send mail for each trouble finded or performance probem.
It's incredibly useful to collect data and produce SLA or to have an workload history of your DB.



Requirements
------------
There are just two requirement:
* working sqlplus on zabbix server with configured tnsnames, and tnsping utility too. 
	I�ve installed a complete client and not simply the instantclient, because tnsping is not included inside instant-client.
* an user on every oracle instances



Installation
-----------
Installation steps:
	* unzip in /etc/zabbix/externalscripts check_ora<VERSION>.tar.gz
	* It's important that you modify with correct path the file "/etc/zabbix/externalscripts/check_ora/globalcfg" something like this:
		export ORACLE_BASE=/usr/local/oracle/10.2.0.4
		export ORACLE_HOME=$ORACLE_BASE
		export PATH=$PATH:$ORACLE_HOME/bin
		export LD_LIBRARY_PATH=/lib/:/usr/lib:$ORACLE_BASE/lib
		export TNS_ADMIN=$ORACLE_HOME/network/admin
		obviously you need replace those with your paths etc..

	* create an user with this oracle script:
		CREATE USER ZABBIX
		IDENTIFIED BY <REPLACE WITH PASSWORD>
		DEFAULT TABLESPACE SYSTEM
		TEMPORARY TABLESPACE TEMP
		PROFILE DEFAULT
		ACCOUNT UNLOCK;
		� 2 Roles for ZABBIX
		GRANT CONNECT TO ZABBIX;
		GRANT RESOURCE TO ZABBIX;
		ALTER USER ZABBIX DEFAULT ROLE ALL;
		� 5 System Privileges for ZABBIX
		GRANT SELECT ANY TABLE TO ZABBIX;
		GRANT CREATE SESSION TO ZABBIX;
		GRANT SELECT ANY DICTIONARY TO ZABBIX;


 
    * write your credentials /username/password and instance etc..) inside /etc/zabbix/externalscripts/check_ora/credentials
   
    * import my template
 
    * schedule on crontab
      */5 * * * * /etc/zabbix/externalscripts/check_ora_cron.sh

Then the last thing to do is add an host with the same name of SID.
an you�ll have a lot of graphs about performaces etc.. 

