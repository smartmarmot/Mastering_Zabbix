select pins/(pins+reloads)*100 "pin_hit ratio"
FROM v$librarycache
where namespace ='BODY';
quit;
