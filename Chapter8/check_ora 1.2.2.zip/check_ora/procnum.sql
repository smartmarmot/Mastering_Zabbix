select count(*) "procnum" from v$process;
quit;
