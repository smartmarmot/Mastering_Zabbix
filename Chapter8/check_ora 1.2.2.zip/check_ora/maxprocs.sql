select value "maxprocs" from v$parameter where name = 'processes';
quit;
