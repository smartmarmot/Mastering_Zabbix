SELECT  to_char(sum(decode(name,'db block gets',value,0)))
FROM V$SYSSTAT 
WHERE NAME ='db block gets';
quit;
