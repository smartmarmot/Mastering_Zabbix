-- Ritorna un campo testo:
-- vuoto se non ci sono locks,
-- con dettagli sui locks nel caso ce ne siano
--select
--   'OWNER->'|| c.owner,
--   'OBJECT_NAME->'|| c.object_name,
--   'OBJECT_TYPE->'||c.object_type,
--   'SID->'||b.sid,
--   'STATUS->'||b.status,
--   'OS USER->'||b.osuser,
--   'MACHINE->'||b.machine,'is blocking  <br />'
--from
--   v$locked_object a ,
--   v$session b,
--   dba_objects c
--where
--   b.sid = a.session_id
--and
--   a.object_id = c.object_id;
--
--SELECT s1.username || '@' || s1.machine
--    || ' ( SID=' || s1.sid || ' ) is blocking '
--    || s2.username || '@' || s2.machine || ' ( SID=' || s2.sid
--    || ' ) on object ' || obj.object_name || ' </br> '
--    AS Blocking_Status
--FROM v$lock l1, v$session s1, v$lock l2, v$session s2, dba_objects obj
--WHERE s1.sid=l1.sid and s2.sid=l2.sid
--    AND l1.BLOCK=1 and l2.request > 0
--    AND l2.ctime > 5
--    AND l1.id1 = l2.id1
--    AND l2.id2 = l2.id2
--    AND obj.object_id = s2.row_wait_obj#;
select	sn.USERNAME ||'@'||sn.machine,
	'|SID->' || m.SID,
	'|Serial->'|| sn.SERIAL#,
	'|Lock Type->'||m.TYPE,
	decode(LMODE,
		0, 'None',
		1, 'Null',
		2, 'Row-S (SS)',
		3, 'Row-X (SX)',
		4, 'Share',
		5, 'S/Row-X (SSX)',
		6, 'Exclusive') lock_type,
	decode(REQUEST,
		0, 'None', 
		1, 'Null',
		2, 'Row-S (SS)',
		3, 'Row-X (SX)', 
		4, 'Share', 
		5, 'S/Row-X (SSX)',
		6, 'Exclusive') lock_requested,
	'|Time (Sec)->'||m.CTIME "Time(sec)",
	'|ID1->'||m.ID1,
	'|ID2->'||m.ID2,
	'|SQL Text->'||t.SQL_TEXT
from 	v$session sn, 
	v$lock m , 
	v$sqltext t
where 	t.ADDRESS = sn.SQL_ADDRESS 
and 	t.HASH_VALUE = sn.SQL_HASH_VALUE 
and 	((sn.SID = m.SID and m.REQUEST != 0) 
or 	(sn.SID = m.SID and m.REQUEST = 0 and LMODE != 4 and (ID1, ID2) in
        (select s.ID1, s.ID2 
         from 	v$lock S 
         where 	REQUEST != 0 
	 and    s.ctime > 5
         and 	s.ID1 = m.ID1 
         and 	s.ID2 = m.ID2)))
order by sn.USERNAME, sn.SID, t.PIECE;
quit;
