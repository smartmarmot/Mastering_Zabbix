-- display the size archive log produced in last 10 minute in MB
select round(A.LOGS*B.AVG/1024/1024/10)
from (
SELECT COUNT (*)  LOGS
FROM V$LOG_HISTORY
WHERE FIRST_TIME >= (sysdate -10/60/24)
) A,
(
SELECT
Avg(BYTES) AVG,
Count(1) Count#,
Max(BYTES) Max_Bytes,
Min(BYTES) Min_Bytes
FROM
v$log) B;
exit;
