SELECT TO_CHAR(ROUND(SUM(decode(pool,'shared pool',decode(name,'library cache',0,'dictionary cache',0,'free memory',0,'sql area',
    0,(bytes)/(1024*1024)),0)),2)) pool_misc
FROM V$SGASTAT;
quit;
