select count(username) from v$session where username is not null;
quit;
