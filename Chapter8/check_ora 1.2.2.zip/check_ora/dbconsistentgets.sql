select to_char(sum(decode(name,'consistent gets', value,0))) "consistent_gets"
FROM v$sysstat;
quit;
