select sum(decode(name,'physical reads', value,0)) "phys_reads"
FROM v$sysstat;
quit;
