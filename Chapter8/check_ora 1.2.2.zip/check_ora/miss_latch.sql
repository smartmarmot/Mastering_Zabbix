SELECT SUM(misses) FROM V$LATCH;
quit;
