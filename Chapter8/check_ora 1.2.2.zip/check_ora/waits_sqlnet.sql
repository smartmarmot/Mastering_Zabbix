SELECT to_char(sum(decode(event,'SQL*Net message to client',total_waits, 'SQL*Net message to dblink',total_waits, 'SQL*Net more data to client',total_waits, 'SQL*Net more data to dblink',total_waits, 'SQL*Net break/reset to client',total_waits, 'SQL*Net break/reset to dblink',total_waits,0))) SQLNET
FROM V$system_event WHERE 1=1 AND event not in (
    'SQL*Net message from client', 
    'SQL*Net more data from client', 
    'pmon timer', 'rdbms ipc message', 
    'rdbms ipc reply', 'smon timer'); 
quit;
