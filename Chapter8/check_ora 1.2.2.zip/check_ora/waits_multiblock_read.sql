SELECT to_char(sum(decode(event,'db file scattered read',total_waits,0))) MultiBlockRead
FROM V$system_event WHERE 1=1 AND event not in (
    'SQL*Net message from client', 
    'SQL*Net more data from client', 
    'pmon timer', 'rdbms ipc message', 
    'rdbms ipc reply', 'smon timer'); 
quit;
