select to_char(sum(decode(name,'physical writes direct',value,0)))
FROM V$SYSSTAT 
where  name ='physical writes direct';
quit;
