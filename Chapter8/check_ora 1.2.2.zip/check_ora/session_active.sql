-- Descrizione di cosa
-- fa la query,
-- possibilmente con tipo di output
--select SUM(Decode(Type, 'BACKGROUND', 0, Decode(Status, 'ACTIVE', 1, 0))) 
--FROM V$SESSION;
select count(*) from v$session where TYPE!= 'BACKGROUND' and status='ACTIVE';
quit;
